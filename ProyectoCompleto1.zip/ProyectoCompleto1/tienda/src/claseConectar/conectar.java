package claseConectar;

import java.sql.*;
import javax.swing.*;
/**
 *
 * @author Sony
 */

public class conectar {
Connection cn= null;
   public Connection conexion()
    {
      try {
             
           Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://"+"databaseName=tienda;user=sa;password=123456789";
            cn= DriverManager.getConnection(connectionUrl);
            
            System.out.println("Conexion Exitosa");
            
            
        } catch (SQLException e) {
           System.out.println("SQL Exception: "+e.toString());
            JOptionPane.showMessageDialog(null,"Error "+e);
        }catch(ClassNotFoundException cE){
            System.out.println("Class not found Exception: "+cE.toString());
        }
        return cn;
     
}}
